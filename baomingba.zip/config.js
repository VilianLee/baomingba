const baseUrl = {
  // webViewUrl: 'https://xcxtest.51bmb.com', //开发
  // imageUrl: 'http://upload.bmbee.cn',//开发
  // baseUrl: 'https://xcxtest.51bmb.com', //开发
  webViewUrl: 'https://xcx.51bmb.com',//生产
  imageUrl: 'https://upload.51bmb.com',//生产
  baseUrl: 'https://xcx.51bmb.com', //生产
  uploadUrl: 'upload.qiniup.com'
};
module.exports = { baseUrl }


// "appid": "wx7758de782c51657c", 测试

// "appid": "wx5fc3a72f2a87b0f6",生产
